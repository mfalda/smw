name(smw).
title('Semantic MediaWiki interaction').
version('0.3.0').
author('Marco Falda', 'marco.falda@gmail.com').
